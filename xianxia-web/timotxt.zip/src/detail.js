function execute(url) {
    var cleanUrl = url;
    if (cleanUrl.endsWith("/dir")) {
        cleanUrl = cleanUrl.substring(0, cleanUrl.length - 4);
    }
    if (!cleanUrl.endsWith("/")) {
        cleanUrl = cleanUrl + "/";
    }

    console.log("[TimoTXT] detail.js loading: " + cleanUrl);
    var res = fetch(cleanUrl);
    if (res && res.ok) {
        var doc = res.html();

        var name = doc.select("meta[property=og:novel:book_name], meta[name=og:novel:book_name]").attr("content");
        if (!name) name = doc.select("h1.title").text().trim();
        if (!name) {
            var h1El = doc.select(".info h1, h1").first();
            if (h1El) name = h1El.text().trim();
        }

        var author = doc.select("meta[property=og:novel:author], meta[name=og:novel:author]").attr("content");
        if (!author) {
            var aEl = doc.select(".info .author, .author").first();
            if (aEl) author = aEl.text().trim();
        }

        var cover = doc.select("meta[property=og:image], meta[name=og:image]").attr("content");
        if (!cover) {
            var coverEl = doc.select(".cover img, img.cover, .col.cover img, .info img").first();
            if (coverEl) cover = coverEl.attr("src");
        }

        var description = doc.select(".intro").text().trim();
        if (!description) description = doc.select("meta[name=description]").attr("content");

        var category = doc.select("meta[property=og:novel:category]").attr("content");
        var status = doc.select("meta[property=og:novel:status]").attr("content");
        var updateTime = doc.select("meta[property=og:novel:update_time]").attr("content");

        var detailParts = [];
        if (author) detailParts.push("作者: " + author);
        if (category) detailParts.push("分類: " + category);
        if (status) detailParts.push("狀態: " + status);
        if (updateTime) detailParts.push("更新: " + updateTime);

        var isOngoing = status ? status.indexOf("連載") >= 0 : true;

        console.log("[TimoTXT] detail.js success: " + name + " by " + author);
        return Response.success({
            name: name,
            cover: cover,
            author: author,
            description: description,
            detail: detailParts.join("<br>"),
            ongoing: isOngoing,
            host: "https://www.timotxt.com"
        });
    }
    return null;
}
