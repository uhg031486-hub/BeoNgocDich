function execute() {
    return Response.success([
        { title: "Khoa huyễn (科幻)", input: "https://www.timotxt.com/bookstack/?cid=10", script: "gen.js" },
        { title: "Đô thị (都市)", input: "https://www.timotxt.com/bookstack/?cid=4", script: "gen.js" },
        { title: "Huyền huyễn (玄幻)", input: "https://www.timotxt.com/bookstack/?cid=5", script: "gen.js" },
        { title: "Xuyên không (穿越)", input: "https://www.timotxt.com/bookstack/?cid=8", script: "gen.js" },
        { title: "Lịch sử (歷史)", input: "https://www.timotxt.com/bookstack/?cid=2", script: "gen.js" },
        { title: "Quân sự (軍事)", input: "https://www.timotxt.com/bookstack/?cid=18", script: "gen.js" },
        { title: "Ngôn tình (言情)", input: "https://www.timotxt.com/bookstack/?cid=1", script: "gen.js" },
        { title: "Vườn trường (校園)", input: "https://www.timotxt.com/bookstack/?cid=13", script: "gen.js" },
        { title: "Thể thao (體育)", input: "https://www.timotxt.com/bookstack/?cid=6", script: "gen.js" },
        { title: "Khác (其他)", input: "https://www.timotxt.com/bookstack/?cid=3", script: "gen.js" },
        { title: "Kênh Nam Sinh (男生)", input: "https://www.timotxt.com/bookstack/boy/", script: "gen.js" },
        { title: "Kênh Nữ Sinh (女生)", input: "https://www.timotxt.com/bookstack/girl/", script: "gen.js" },
        { title: "Truyện Đã Hoàn Thành (完本)", input: "https://www.timotxt.com/bookstack/?finish=1", script: "gen.js" }
    ]);
}
