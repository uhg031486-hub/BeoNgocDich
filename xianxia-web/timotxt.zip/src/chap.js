
var SPECIAL_CN_WORDS = {
    "理直气壮": "hùng hồn",
    "理所当然": "đương nhiên",
    "寒暄": "chào hỏi xã giao",
    "纷纷": "nhao nhao",
    "讲究": "câu nệ",
    "潇洒": "phóng khoáng",
    "伤筋动骨": "tổn thương gân cốt",
    "撞": "va đập",
    "闹得": "làm ĩ",
    "闺誉": "thanh danh khuê các",
    "鳏夫": "gã góa vợ",
    "领情": "cảm kích",
    "打闹": "đùa nghịch xô xát",
    "预谋": "mưu tính từ trước",
    "亏心": "thất đức",
    "暗自": "thầm",
    "愣住": "ngây ngẩn",
    "随即": "ngay sau đó",
    "仿佛": "dường như",
    "恍然": "bừng tỉnh",
    "恍惚": "thẫn thờ",
    "猛地": "đột ngột",
    "猛地下": "đột ngột",
    "瘫在": "ngã vật ra",
    "瘫倒": "ngã vật ra",
    "瘫坐在": "ngồi phịch xuống",
    "偏偏": "ngặt nỗi",
    "顿时": "tức thì",
    "微微": "khẽ",
    "悄悄": "lặng lẽ",
    "冷哼": "hừ lạnh",
    "冷笑": "cười lạnh",
    "淡然": "thản nhiên",
    "蓦然": "chợt",
    "倏地": "thoắt cái",
    "赫然": "rõ ràng",
    "汪汪汪": "gâu gâu gâu",
    "汪汪": "gâu gâu",
    "汪": "gâu",
    "喵喵": "meo meo",
    "喵": "meo",
    "轰隆": "ầm ầm",
    "砰": "bùm"
};

function cleanResidualChinese(text) {
    if (!text) return "";
    var res = String(text);
    for (var k in SPECIAL_CN_WORDS) {
        if (res.indexOf(k) >= 0) {
            res = res.split(k).join(" " + SPECIAL_CN_WORDS[k] + " ");
        }
    }
    res = res.replace(/[\u4e00-\u9fff\u3400-\u4dbf\uf900-\ufaff]+/g, " ");
    res = res.replace(/[ \t]+/g, " ")
             .replace(/\s+([,.\?!;:])/g, "$1")
             .replace(/([“"‘\(\[])\s+/g, "$1")
             .replace(/\s+([”"’\)\]])/g, "$1");
    return res.trim();
}

function execute(url) {
    console.log("[TimoTXT] chap.js loading: " + url);
    var match = url.match(/\/(\d+)\/(\d+)\.html/);
    if (match) {
        var bid = match[1];
        var cid = parseInt(match[2], 10);

        // 1. Gửi tín hiệu Reader Trigger cho Server (Preemptive Priority Translation)
        try {
            var triggerUrl = "https://timo-search.cloudflare-timo-search.workers.dev/api/timo/reader-trigger?bid=" + bid + "&cid=" + cid;
            fetch(triggerUrl, { headers: { "User-Agent": "vBook" } });
        } catch (eTrigger) {}

        // 2. Kiểm tra bản dịch tiếng Việt có sẵn từ Server (Tốc độ mở 0.02s)
        try {
            var transUrl = "https://timo-search.cloudflare-timo-search.workers.dev/api/timo/chapter?bid=" + bid + "&cid=" + cid;
            var transRes = fetch(transUrl, { headers: { "User-Agent": "vBook" } });
            if (transRes && transRes.ok) {
                var transJson = transRes.json();
                if (transJson && transJson.ok && transJson.found && transJson.content) {
                    console.log("[TimoTXT] Loaded pre-translated VN chapter: " + bid + "/" + cid);
                    return Response.success(cleanResidualChinese(transJson.content));
                }
            }
        } catch (eTrans) {}

        // 3. Nếu Server chưa có bản dịch: Tải tiếng Trung gốc từ TimoTXT
        var apiUrl = "https://www.timotxt.com/chapter/transcode.html?bid=" + bid + "&cid=" + cid + "&sid=8096";

        var res = fetch(apiUrl, {
            headers: {
                "X-Requested-With": "XMLHttpRequest"
            }
        });

        if (res && res.ok) {
            var json = res.json();
            if (json && json.content) {
                var content = json.content;
                var lines = content.replace(/&nbsp;/g, " ").replace(/\r\n/g, "\n").split("\n");
                var cleanLines = [];
                for (var i = 0; i < lines.length; i++) {
                    var l = lines[i].trim();
                    if (l.length > 0) {
                        cleanLines.push(l);
                    }
                }
                var formatted = cleanLines.join("<br><br>");
                console.log("[TimoTXT] chap.js transcode success: " + formatted.length + " chars");
                return Response.success(formatted);
            }
        }

        // Fallback: Fetch chapter HTML directly
        var pageRes = fetch(url);
        if (pageRes && pageRes.ok) {
            var pageText = pageRes.text();
            var sidMatch = pageText.match(/sid\s*:\s*(\d+)/);
            if (sidMatch && sidMatch[1] !== "8096") {
                var retryUrl = "https://www.timotxt.com/chapter/transcode.html?bid=" + bid + "&cid=" + cid + "&sid=" + sidMatch[1];
                var retryRes = fetch(retryUrl, {
                    headers: {
                        "X-Requested-With": "XMLHttpRequest"
                    }
                });
                if (retryRes && retryRes.ok) {
                    var rJson = retryRes.json();
                    if (rJson && rJson.content) {
                        var lines2 = rJson.content.replace(/&nbsp;/g, " ").replace(/\r\n/g, "\n").split("\n");
                        var cleanLines2 = [];
                        for (var j = 0; j < lines2.length; j++) {
                            var l2 = lines2[j].trim();
                            if (l2.length > 0) {
                                cleanLines2.push(l2);
                            }
                        }
                        return Response.success(cleanLines2.join("<br><br>"));
                    }
                }
            }
        }
    }
    return null;
}
