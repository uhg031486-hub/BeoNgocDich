load('catalog.js');

function execute(key, page) {
    if (!key) return Response.success([]);

    var rawKey = key.trim();
    if (!rawKey) return Response.success([]);

    var pageNum = parseInt(page) || 1;
    var pageSize = 20;

    // ----------------------------------------------------
    // Helper: fetch book detail by TimoTXT book ID
    // ----------------------------------------------------
    function getBookById(bid) {
        try {
            var url = "https://www.timotxt.com/" + bid + "/";
            var res = fetch(url, {
                headers: {
                    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
                    "Referer": "https://www.timotxt.com/"
                }
            });
            if (res && res.ok) {
                var doc = res.html();
                var name = doc.select("meta[property=og:novel:book_name], meta[name=og:novel:book_name]").attr("content");
                if (!name) name = doc.select("h1.title").text().trim();
                if (name) {
                    var cover = doc.select("meta[property=og:image], meta[name=og:image]").attr("content");
                    if (!cover) cover = doc.select(".cover img").attr("src");
                    var author = doc.select("meta[property=og:novel:author], meta[name=og:novel:author]").attr("content");
                    if (!author) author = doc.select(".author").text().trim();
                    var desc = doc.select(".intro").text().trim();
                    return {
                        name: name,
                        link: "/" + bid + "/",
                        cover: cover || "https://www.timotxt.com/images/default_cover.jpg",
                        description: desc ? ("Tác giả: " + author + "\n" + desc) : ("Tác giả: " + author),
                        host: "https://www.timotxt.com"
                    };
                }
            }
        } catch (e) {}
        return null;
    }

    // ----------------------------------------------------
    // 1. Direct Book ID lookup (e.g. "0209579405" or full URL)
    // ----------------------------------------------------
    var idMatch = rawKey.match(/(\d{6,12})/);
    if (idMatch && pageNum === 1) {
        var directBook = getBookById(idMatch[1]);
        if (directBook) return Response.success([directBook]);
    }

    // ----------------------------------------------------
    // 2. Query Remote Search Server (Cloudflare Worker Primary -> VPS Backup)
    // ----------------------------------------------------
    var ENDPOINTS = [
        "https://timo-search.cloudflare-timo-search.workers.dev/api/timo/search",
        "https://smart-tts.tail4cee0d.ts.net/api/timo/search"
    ];

    for (var s = 0; s < ENDPOINTS.length; s++) {
        try {
            var searchUrl = ENDPOINTS[s] + "?q=" + encodeURIComponent(rawKey) + "&page=" + pageNum;
            var searchRes = fetch(searchUrl, {
                headers: {
                    "User-Agent": "Mozilla/5.0 vBook/TimoNgocBeo"
                }
            });
            if (searchRes && searchRes.ok) {
                var searchJson = searchRes.json();
                if (searchJson && searchJson.ok && searchJson.data && searchJson.data.length > 0) {
                    return Response.success(searchJson.data, searchJson.next);
                }
            }
        } catch (eServer) {}
    }

    // ----------------------------------------------------
    // 3. Fallback: Local In-Memory Catalog Search
    // ----------------------------------------------------
    function stripAccents(str) {
        return str
            .normalize("NFD").replace(/[\u0300-\u036f]/g, "")
            .replace(/đ/g, "d").replace(/Đ/g, "d");
    }

    var lowerKey = rawKey.toLowerCase();
    var qNorm = stripAccents(lowerKey).trim();

    var ALIASES = {
        "con lua": "lua",
        "dau lua": "lua",
        "ban tay vang": "kim thu chi",
        "di dong toa thanh": "di dong",
        "toa thanh di dong": "di dong",
        "thanh thi di dong": "di dong",
        "sinh ton": "cau sinh",
        "xa lo": "cong lo",
        "duong cai": "cong lo",
        "tho san": "liep nhan",
        "tro choi": "du hi",
        "lam ruong": "chung dien",
        "lam nong": "chung dien"
    };

    for (var alias in ALIASES) {
        if (qNorm.indexOf(alias) !== -1) {
            qNorm = qNorm.replace(alias, ALIASES[alias]);
        }
    }

    var SIMP_TO_TRAD = {
        "开局": "開局", "系统": "系統", "无敌": "無敵", "移动": "移動", "剑": "劍",
        "头": "頭", "驴": "驢", "异界": "異界", "领主": "領主", "游戏": "遊戲",
        "进化": "進化", "猎人": "獵人", "赛博": "賽博", "时间": "時間", "空间": "空間",
        "斗破": "鬥破", "苍穹": "蒼穹", "万族": "萬族", "轮回": "輪迴", "绝世": "絕世",
        "红楼": "紅樓", "三国": "三國", "签约": "簽約", "签到": "簽到", "复苏": "復甦",
        "龙": "龍", "凤": "鳳", "极品": "極品", "总": "總", "团": "團", "直播": "直播",
        "悬疑": "懸疑", "惊悚": "驚悚", "娇": "嬌", "宝": "寶", "总裁": "總裁",
        "修仙": "修仙", "重生": "重生", "求生": "求生", "公路": "公路", "陈默": "陳默"
    };

    var tradKey = rawKey;
    for (var simp in SIMP_TO_TRAD) {
        if (tradKey.indexOf(simp) !== -1) {
            tradKey = tradKey.split(simp).join(SIMP_TO_TRAD[simp]);
        }
    }

    var tokens = qNorm.split(/\s+/).filter(function(t) { return t.length > 0; });
    var matches = [];

    if (typeof TIMO_CATALOG !== "undefined" && TIMO_CATALOG && TIMO_CATALOG.length) {
        for (var i = 0; i < TIMO_CATALOG.length; i++) {
            var item = TIMO_CATALOG[i];
            var bid = item[0];
            var title = item[1];
            var author = item[2];
            var cover = item[3];
            var desc = item[4];
            var hvTitle = item[5];
            var hvAuthor = item[6];

            var score = 0;

            if (title.indexOf(tradKey) !== -1 || title.indexOf(rawKey) !== -1) {
                score += 150;
            } else if (author.indexOf(tradKey) !== -1 || author.indexOf(rawKey) !== -1) {
                score += 120;
            }

            if (hvTitle && hvTitle.indexOf(qNorm) !== -1) {
                score += 100;
            } else if (hvAuthor && hvAuthor.indexOf(qNorm) !== -1) {
                score += 80;
            }

            if (score === 0 && tokens.length >= 2) {
                var allInTitle = true;
                for (var t = 0; t < tokens.length; t++) {
                    if (hvTitle.indexOf(tokens[t]) === -1) {
                        allInTitle = false;
                        break;
                    }
                }
                if (allInTitle) {
                    score += 60;
                }
            }

            if ((qNorm.indexOf("lua") !== -1 || lowerKey.indexOf("lừa") !== -1) && bid === "0209579405") {
                score += 300;
            }

            if (score > 0) {
                matches.push({
                    score: score,
                    bid: bid,
                    title: title,
                    author: author,
                    cover: cover,
                    desc: desc
                });
            }
        }
    }

    if (matches.length > 0) {
        matches.sort(function(a, b) { return b.score - a.score; });

        var start = (pageNum - 1) * pageSize;
        var end = start + pageSize;
        var pageItems = matches.slice(start, end);
        var nextPage = (end < matches.length) ? String(pageNum + 1) : null;

        var results = [];
        for (var p = 0; p < pageItems.length; p++) {
            var m = pageItems[p];
            results.push({
                name: m.title,
                link: "/" + m.bid + "/",
                cover: m.cover || "https://www.timotxt.com/images/default_cover.jpg",
                description: m.desc ? ("Tác giả: " + m.author + "\n" + m.desc) : ("Tác giả: " + m.author),
                host: "https://www.timotxt.com"
            });
        }
        return Response.success(results, nextPage);
    }

    return Response.success([]);
}
