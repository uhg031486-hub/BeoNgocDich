function execute() {
    return Response.success([
        { title: "Mới cập nhật", input: "https://www.timotxt.com/bookstack/", script: "gen.js" },
        { title: "Bảng xếp hạng", input: "https://www.timotxt.com/ranking.html", script: "gen.js" },
        { title: "Khoa huyễn", input: "https://www.timotxt.com/bookstack/?cid=10", script: "gen.js" },
        { title: "Đô thị", input: "https://www.timotxt.com/bookstack/?cid=4", script: "gen.js" },
        { title: "Huyền huyễn", input: "https://www.timotxt.com/bookstack/?cid=5", script: "gen.js" },
        { title: "Nam sinh", input: "https://www.timotxt.com/bookstack/boy/", script: "gen.js" },
        { title: "Nữ sinh", input: "https://www.timotxt.com/bookstack/girl/", script: "gen.js" },
        { title: "Hoàn thành", input: "https://www.timotxt.com/bookstack/?finish=1", script: "gen.js" }
    ]);
}
