function execute(url, page) {
    if (!page) page = "1";

    var targetUrl = url;
    // TimoTXT requires trailing slash on directory URLs like /bookstack/
    if (targetUrl.indexOf(".html") === -1 && targetUrl.indexOf("?") === -1 && !targetUrl.endsWith("/")) {
        targetUrl = targetUrl + "/";
    }

    if (targetUrl.indexOf("ranking.html") === -1) {
        if (page !== "1") {
            if (targetUrl.indexOf("?") !== -1) {
                targetUrl = targetUrl + "&page=" + page;
            } else {
                targetUrl = targetUrl + "?page=" + page;
            }
        }
    }

    var res = fetch(targetUrl, {
        headers: {
            "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
        }
    });

    if (res && res.ok) {
        var doc = res.html();
        var items = doc.select(".search-list ul.list li.row, ul.list li.row");
        var data = [];

        for (var i = 0; i < items.size(); i++) {
            var el = items.get(i);
            var linkEl = el.select("h3 a").first();
            if (linkEl) {
                var name = linkEl.text().trim();
                var link = linkEl.attr("href");
                var coverEl = el.select("img").first();
                var cover = coverEl ? coverEl.attr("src") : "";
                var descEl = el.select("p.desc").first();
                var desc = descEl ? descEl.text().trim() : "";
                var authorEl = el.select("span.author").first();
                var author = authorEl ? authorEl.text().trim() : "";

                data.push({
                    name: name,
                    link: link,
                    cover: cover,
                    description: desc ? ("Tác giả: " + author + "\n" + desc) : ("Tác giả: " + author),
                    host: "https://www.timotxt.com"
                });
            }
        }

        if (data.length > 0 && url.indexOf("ranking.html") === -1) {
            var nextPage = (parseInt(page, 10) + 1).toString();
            return Response.success(data, nextPage);
        }
        return Response.success(data);
    }
    return null;
}
