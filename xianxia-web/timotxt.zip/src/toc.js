function execute(url) {
    var dirUrl = url;
    if (dirUrl.endsWith("/")) {
        dirUrl = dirUrl + "dir";
    } else if (!dirUrl.endsWith("/dir")) {
        dirUrl = dirUrl + "/dir";
    }

    var match = url.match(/\/(\d+)\/?/);
    var bid = match ? match[1] : null;

    // 1. Tải danh sách các chương đã dịch từ Cloudflare D1
    var translatedCids = {};
    if (bid) {
        try {
            var transCidsUrl = "https://timo-search.cloudflare-timo-search.workers.dev/api/timo/translated-cids?bid=" + bid;
            var cidsRes = fetch(transCidsUrl, { headers: { "User-Agent": "vBook" } });
            if (cidsRes && cidsRes.ok) {
                var cidsJson = cidsRes.json();
                if (cidsJson && cidsJson.ok && cidsJson.cids) {
                    translatedCids = cidsJson.cids;
                }
            }
        } catch (eCids) {}
    }

    console.log("[TimoTXT] toc.js loading: " + dirUrl);
    var res = fetch(dirUrl);
    if (res && res.ok) {
        var doc = res.html();

        var el = doc.select("ul.all li a");
        if (el.size() === 0) {
            el = doc.select("ul.flex.all li a");
        }
        if (el.size() === 0) {
            el = doc.select(".chaplist ul li a");
        }

        var chapters = [];
        var seen = {};

        for (var i = 0; i < el.size(); i++) {
            var a = el.get(i);
            var href = a.attr("href");
            var name = a.text().trim();
            if (name && href.indexOf(".html") !== -1 && !seen[href]) {
                seen[href] = true;

                var chapCidMatch = href.match(/\/(\d+)\.html/);
                var chapCid = chapCidMatch ? parseInt(chapCidMatch[1], 10) : null;
                
                var displayName = name;
                if (chapCid && translatedCids[chapCid]) {
                    var viTitle = translatedCids[chapCid];
                    displayName = (typeof viTitle === "string" && viTitle.length > 0) ? ("✓ " + viTitle) : ("✓ " + name);
                }

                chapters.push({
                    name: displayName,
                    url: href,
                    host: "https://www.timotxt.com"
                });
            }
        }
        console.log("[TimoTXT] toc.js found chapters: " + chapters.length);
        return Response.success(chapters);
    }
    return null;
}
