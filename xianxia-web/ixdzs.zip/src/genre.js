function execute() {
    return Response.success([
        { title: "Huyền Huyễn Kỳ Huyễn", input: "https://ixdzs.tw/sort/1/", script: "gen.js" },
        { title: "Tu Chân Tiên Hiệp", input: "https://ixdzs.tw/sort/2/", script: "gen.js" },
        { title: "Đô Thị Thanh Xuân", input: "https://ixdzs.tw/sort/3/", script: "gen.js" },
        { title: "Quân Sự Lịch Sử", input: "https://ixdzs.tw/sort/4/", script: "gen.js" },
        { title: "Võng Du Cạnh Kỹ", input: "https://ixdzs.tw/sort/5/", script: "gen.js" },
        { title: "Khoa Huyễn Linh Dị", input: "https://ixdzs.tw/sort/6/", script: "gen.js" },
        { title: "Ngôn Tình Xuyên Việt", input: "https://ixdzs.tw/sort/7/", script: "gen.js" },
        { title: "Đam Mỹ Đồng Nhân", input: "https://ixdzs.tw/sort/8/", script: "gen.js" },
        { title: "Truyền Thống Võ Hiệp", input: "https://ixdzs.tw/sort/10/", script: "gen.js" },
        { title: "Đài Ngôn Cổ Ngôn", input: "https://ixdzs.tw/sort/9/", script: "gen.js" },
        { title: "Tiểu Thuyết Khác", input: "https://ixdzs.tw/sort/0/", script: "gen.js" }
    ]);
}
