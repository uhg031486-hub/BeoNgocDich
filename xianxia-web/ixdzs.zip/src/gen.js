function getHtml(url) {
    if (typeof Http !== 'undefined' && Http.get) {
        try {
            var doc = Http.get(url).html();
            if (doc) return doc;
        } catch (eHttp) {}
    }
    try {
        var resp = fetch(url, {
            headers: {
                "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
            }
        });
        if (resp && resp.ok) return resp.html();
    } catch (eFetch) {}
    return null;
}

function execute(url, page) {
    if (!page) page = "1";
    if (page !== "1") {
        url = page.indexOf("http") === 0 ? page : ("https://ixdzs.tw" + (page.indexOf("/") === 0 ? "" : "/") + page);
    }
    var html = getHtml(url);
    if (!html) return Response.error("Lỗi tải trang ixdzs.tw");

    var next = null;
    var next_TF = html.select(".pagei a[title*='下一頁'], .pagei a[title*='下一页']").first();
    if (next_TF) {
        next = next_TF.attr("href");
    }

    var el = html.select(".u-list li");
    var data = [];
    for (var i = 0; i < el.size(); i++) {
        var e = el.get(i);
        var imgEl = e.select(".l-img img").first();
        var cover = imgEl ? imgEl.attr("src") : "";
        if (cover && cover.indexOf("http") !== 0) {
            cover = "https://ixdzs.tw" + (cover.indexOf("/") === 0 ? "" : "/") + cover;
        }
        var nameEl = e.select(".bname a").first();
        var name = nameEl ? nameEl.text().trim() : "";
        var authorEl = e.select(".bauthor a").first();
        var author = authorEl ? authorEl.text().trim() : "";
        var aEl = e.select(".l-img a, .bname a").first();
        var href = aEl ? aEl.attr("href") : "";
        var link = href.indexOf("http") === 0 ? href : ("https://ixdzs.tw" + (href.indexOf("/") === 0 ? "" : "/") + href);

        if (name) {
            data.push({
                name: name,
                link: link,
                cover: cover,
                description: author,
                host: "https://ixdzs.tw"
            });
        }
    }
    return Response.success(data, next);
}
