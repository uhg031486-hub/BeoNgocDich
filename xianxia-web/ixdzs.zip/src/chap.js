function execute(url) {
    var doc = null;
    if (typeof Http !== 'undefined' && Http.get) {
        try {
            doc = Http.get(url).html();
        } catch (eHttp) {}
    }
    if (!doc) {
        try {
            var response = fetch(url, {
                headers: {
                    "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
                    "referer": "https://ixdzs.tw/"
                }
            });
            if (response && response.ok) {
                doc = response.html();
            }
        } catch (eFetch) {}
    }

    if (!doc) {
        return Response.error("Không thể tải nội dung chương từ ixdzs.tw");
    }

    // Xóa sạch script, style, nav buttons, thanh % tiến độ (nguyên nhân gây clone chương có mỗi %)
    doc.select("script, style, div.read-prog-val, output, div.c-nav, div.bottem2, div.bottem, div.page-nav, div.footer").remove();

    var contentContainer = doc.select(".page-content");
    if (contentContainer.size() === 0) {
        contentContainer = doc.select("article");
    }
    if (contentContainer.size() === 0) {
        contentContainer = doc.select("#content");
    }
    if (contentContainer.size() === 0) {
        return Response.error("Không tìm thấy nội dung chương");
    }

    var pElements = contentContainer.select("p");
    var paragraphs = [];

    for (var i = 0; i < pElements.size(); i++) {
        var pText = pElements.get(i).text().trim();
        if (!pText) continue;
        if (pText === "%" || pText === "％") continue;
        if (/^(?:上一章|下一章|目錄|進度|設置|夜間|加入書架|書籍頁|首頁|其他|查看完整章節目錄)$/i.test(pText)) continue;
        if (pText.indexOf("上一章") >= 0 && pText.indexOf("下一章") >= 0) continue;
        paragraphs.push(pText);
    }

    if (paragraphs.length === 0) {
        var sec = contentContainer.select("section");
        var rawText = sec.size() > 0 ? sec.text() : contentContainer.text();
        var lines = rawText.split("\n");
        for (var j = 0; j < lines.length; j++) {
            var lText = lines[j].trim();
            if (!lText || lText === "%" || lText === "％") continue;
            if (/^(?:上一章|下一章|目錄|進度|設置|夜間|加入書架|書籍頁|首頁|其他)$/i.test(lText)) continue;
            paragraphs.push(lText);
        }
    }

    if (paragraphs.length === 0) {
        return Response.error("Nội dung chương trống");
    }

    return Response.success(paragraphs.join("<br><br>"));
}
