function execute(url) {
    var match = url.match(/read\/(\d+)/);
    if (!match) return Response.error("URL không hợp lệ: " + url);
    var bookId = match[1];

    var list = [];
    var seen = {};

    function addLink(name, href) {
        if (!name || !href) return;
        name = name.trim();
        href = href.trim();
        if (!name || !href) return;
        if (href.indexOf("#") === 0 || href.indexOf("javascript") >= 0) return;
        if (/^(?:查看完整章節目錄|首頁|目錄|進度|設置|夜間|%|％)$/i.test(name)) return;
        if (name.indexOf("查看完整章節目錄") >= 0) return;

        var fullUrl = href;
        if (fullUrl.indexOf("http") !== 0) {
            fullUrl = "https://ixdzs.tw" + (fullUrl.indexOf("/") === 0 ? "" : "/") + fullUrl;
        }

        if (seen[fullUrl]) return;
        seen[fullUrl] = true;

        list.push({
            name: name,
            url: fullUrl,
            host: "https://ixdzs.tw"
        });
    }

    // Cách 1: POST /novel/html/ trả về toàn bộ mục lục sạch từ chương 1 đến cuối
    try {
        var postResp = fetch("https://ixdzs.tw/novel/html/", {
            method: "POST",
            headers: {
                "content-type": "application/x-www-form-urlencoded",
                "x-requested-with": "XMLHttpRequest",
                "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
                "referer": "https://ixdzs.tw/read/" + bookId + "/"
            },
            body: "bid=" + bookId
        });
        if (postResp && postResp.ok) {
            var html = postResp.html();
            var links = html.select("li a");
            for (var i = 0; i < links.size(); i++) {
                var el = links.get(i);
                addLink(el.text(), el.attr("href"));
            }
        }
    } catch (ePost) {}

    // Cách 2: Fallback lấy trang /read/{bid}/, lọc bỏ .cfirst (khối chứa chương mới nhất đảo ngược)
    if (list.length === 0) {
        try {
            var getDoc = null;
            if (typeof Http !== 'undefined' && Http.get) {
                try {
                    getDoc = Http.get("https://ixdzs.tw/read/" + bookId + "/").html();
                } catch (eHttp) {}
            }
            if (!getDoc) {
                var getResp = fetch("https://ixdzs.tw/read/" + bookId + "/", {
                    headers: {
                        "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
                    }
                });
                if (getResp && getResp.ok) getDoc = getResp.html();
            }
            if (getDoc) {
                var mainUl = getDoc.select("ul.u-chapter:not(.cfirst)");
                var links = mainUl.size() > 0 ? mainUl.select("li a") : getDoc.select("ul.u-chapter li a");
                for (var j = 0; j < links.size(); j++) {
                    var elGet = links.get(j);
                    addLink(elGet.text(), elGet.attr("href"));
                }
            }
        } catch (eGet) {}
    }

    if (list.length === 0) {
        return Response.error("Không tìm thấy danh sách chương trên ixdzs.tw");
    }

    return Response.success(list);
}
