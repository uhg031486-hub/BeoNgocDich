function getHtml(url) {
    if (typeof Http !== 'undefined' && Http.get) {
        try {
            var doc = Http.get(url).html();
            if (doc) return doc;
        } catch (eHttp) {}
    }
    try {
        var resp = fetch(url, {
            headers: {
                "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
            }
        });
        if (resp && resp.ok) return resp.html();
    } catch (eFetch) {}
    return null;
}

function execute(url) {
    var doc = getHtml(url);
    if (!doc) return Response.error("Không thể mở trang thông tin truyện");

    var name = doc.select(".n-text h1").text().trim();
    var imgEl = doc.select(".n-img img").first();
    var cover = imgEl ? imgEl.attr("src") : "";
    if (cover && cover.indexOf("http") !== 0) {
        cover = "https://ixdzs.tw" + (cover.indexOf("/") === 0 ? "" : "/") + cover;
    }

    var authorEl = doc.select(".n-text p a").first();
    var author = authorEl ? authorEl.text().trim() : "";

    var introEl = doc.select("#intro");
    var description = "";
    if (introEl.size() > 0) {
        var introHtml = introEl.html().split("<span class=\"icon icon-arrow-d c-more\">")[0];
        description = introHtml.replace(/\n/g, "<br>");
    }

    var pList = doc.select(".n-text p");
    var wordCount = pList.size() > 2 ? pList.get(2).select("span").text().trim() : "";
    var latestChap = pList.size() > 3 ? pList.get(3).select("a").text().trim() : "";
    var statusText = pList.size() > 1 ? pList.get(1).select("span").text().trim() : "";
    var detail = "Tác giả: " + author;
    if (statusText) detail += "<br>Trạng thái: " + statusText;
    if (wordCount) detail += "<br>Số chữ: " + wordCount;
    if (latestChap) detail += "<br>Mới nhất: " + latestChap;

    var ongoing = false;
    if (statusText.indexOf("連載") >= 0) {
        ongoing = true;
    }

    return Response.success({
        name: name,
        cover: cover,
        author: author,
        description: description,
        detail: detail,
        ongoing: ongoing,
        host: "https://ixdzs.tw"
    });
}
