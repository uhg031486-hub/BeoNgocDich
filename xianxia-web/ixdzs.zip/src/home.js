function execute() {
    return Response.success([
        { title: "Hoàn tất tác phẩm", input: "https://ixdzs.tw/end/", script: "gen.js" },
        { title: "Tổng bảng", input: "https://ixdzs.tw/hot/", script: "gen.js" },
        { title: "Nguyệt bảng", input: "https://ixdzs.tw/hot/month/", script: "gen.js" },
        { title: "Nhật bảng", input: "https://ixdzs.tw/hot/day/", script: "gen.js" },
        { title: "Mới cập nhật", input: "https://ixdzs.tw/new/", script: "gen.js" }
    ]);
}
